# BCATP-Picton_Aerodrome
Recreation for X-Plane 11, of Picton, Ontario, (Camp Picton) Aerodrome c. 1945 under the British Commonwealth Air Training Plan
 
[Aerial View of the Aerodrome and environs](https://en.wikipedia.org/wiki/CFB_Picton)
 
<a title="unknown.   Canada.   Department of National Defence., Public domain, via Wikimedia Commons" href="https://commons.wikimedia.org/wiki/File:RCAF_Picton_Aerial_View_1940s.jpg"><img width="512" alt="RCAF Picton Aerial View 1940s" src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/88/RCAF_Picton_Aerial_View_1940s.jpg/512px-RCAF_Picton_Aerial_View_1940s.jpg"></a>
